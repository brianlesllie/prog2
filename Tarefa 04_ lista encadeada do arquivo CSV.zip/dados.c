
/* de um arquivo CSV conforme o padrão: 
  *         Series;Value;Time
  *         <int>;<float>;<string> 
  *         <int>;<float>;<string> */
  
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "lista_enc.h"
#include "dados.h"

struct dados {
    int amostra;        /*!< Identificador numérido da amostra */
    float temperatura;  /*!< Valor do dado: temperatura */
    char tempo[64];      /*!< Time stamp */
};


dado_t * criar_dado (int amostra, float temperatura, char * tempo){
    
    dado_t * meu_novo_dado = malloc(sizeof(struct dados));
    
    
    // Colocar a criação dos dados aqui
    
    meu_novo_dado->amostra=amostra;
    meu_novo_dado->temperatura=temperatura;
    strcpy(meu_novo_dado->tempo,tempo);
    
    return meu_novo_dado;
}



lista_enc_t *ler_dados_csv(char *nome_do_arquivo){
    char texto[64];
   
    /* Demais Variáveis */
    lista_enc_t *lista;
    dado_t *dado;
    no_t *meu_no;
    int amostra;
    float temperatura;
    char tempo[64];
    
    FILE *fp = fopen(nome_do_arquivo,"r");
    
    if (!fp){
        perror("ler_dados_csv");
        exit(-1);
    }
    
    lista = criar_lista_enc();
    
    /* Ignora primeira linha */
    fgets(texto,64, fp);

    /* Note que não e mais necessário contar as linhas */


    while (fscanf (fp, "%d,%f,%63[^\n]", &amostra, &temperatura, tempo) == 3){
        printf("Lido %d, %f, %s\n", amostra, temperatura, tempo);
        
        /* Cria um novo dado abstrato e armazena a sua referência */
        
        dado = criar_dado(amostra, temperatura, tempo);
        meu_no = criar_no(dado);
        add_cauda(lista, meu_no);
    }
    fclose(fp);
    return lista;
}

int obter_amostra(dado_t *dado){
    return (dado->amostra);
}
float obter_temperatura(dado_t *dado){
    return dado->temperatura;
}
char *obter_tempo(dado_t *dado){
    return dado->tempo;
}

void liberar_dados(lista_enc_t *lista){
    no_t *no=obter_cabeca(lista);
	no_t *no_prox;
	while(no!=NULL){
		free(obter_dado(no));
		no_prox=obter_proximo(no);
		free(no);
		no=no_prox;
	}
	free(lista);
}
    
    



