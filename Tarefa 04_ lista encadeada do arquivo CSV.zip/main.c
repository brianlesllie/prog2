/** Programa que exibe na tela dados formatados
  * de um arquivo CSV conforme o padrão: 
  *         Series;Value;Time
  *         <int>;<float>;<string> 
  *         <int>;<float>;<string>
  */ 
  
#include <stdio.h>
#include "dados.h"
#include "lista_enc.h"


int main(){
    lista_enc_t *lista = ler_dados_csv("camera_temp.csv");
    dado_t *dado;
    no_t *meu_no;
    meu_no=obter_cabeca(lista);
     
    /* Imprima os dados:*/
    while (meu_no){
        dado=obter_dado(meu_no);
        printf( "%d,%f,%s\n", obter_amostra(dado),obter_temperatura(dado),obter_tempo(dado));
        meu_no=obter_proximo(meu_no);
    }

    liberar_dados(lista);
    
    
    return 0;
}